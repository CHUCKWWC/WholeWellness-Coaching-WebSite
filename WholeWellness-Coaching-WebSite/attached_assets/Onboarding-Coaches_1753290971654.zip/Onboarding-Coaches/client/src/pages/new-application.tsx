import CoachApplicationForm from "@/components/coach-application-form";

export default function NewApplication() {
  return <CoachApplicationForm />;
}