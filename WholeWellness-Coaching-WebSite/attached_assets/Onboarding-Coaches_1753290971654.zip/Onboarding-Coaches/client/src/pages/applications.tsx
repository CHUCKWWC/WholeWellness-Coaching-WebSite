import ApplicationsDashboard from "@/components/applications-dashboard";

export default function Applications() {
  return <ApplicationsDashboard />;
}