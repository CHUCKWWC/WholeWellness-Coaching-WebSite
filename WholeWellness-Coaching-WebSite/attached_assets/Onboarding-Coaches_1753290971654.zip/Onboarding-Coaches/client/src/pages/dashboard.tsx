import ApplicationsDashboard from "@/components/applications-dashboard";

export default function Dashboard() {
  return <ApplicationsDashboard />;
}