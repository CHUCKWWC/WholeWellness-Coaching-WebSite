#!/bin/bash
echo "Starting WholeWellness Chatbot Server..."
cd chatbot-project
node simple-chatbot.js